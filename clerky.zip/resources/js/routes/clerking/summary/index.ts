import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\ClerkingController::generate
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
export const generate = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/summary/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::generate
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
generate.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return generate.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::generate
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
generate.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::generate
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
    const generateForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::generate
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
        generateForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(args, options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
export const edit = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}/summary/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
edit.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return edit.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
edit.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
edit.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
    const editForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
        editForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::edit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
        editForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::update
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
export const update = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/dashboard/clerking/{clerking}/summary',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::update
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
update.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return update.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::update
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
update.patch = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::update
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
    const updateForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::update
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        updateForm.patch = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const summary = {
    generate: Object.assign(generate, generate),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
}

export default summary