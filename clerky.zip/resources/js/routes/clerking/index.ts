import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import summary7469d3 from './summary'
/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
export const summary = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(args, options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return summary.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
    const summaryForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summary.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        summaryForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        summaryForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summary.form = summaryForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
export const pause = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

pause.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
pause.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return pause.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
pause.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
    const pauseForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pause.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
        pauseForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pause.url(args, options),
            method: 'post',
        })
    
    pause.form = pauseForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
export const resume = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
resume.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return resume.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
resume.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
    const resumeForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
        resumeForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(args, options),
            method: 'post',
        })
    
    resume.form = resumeForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
export const sync = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
sync.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return sync.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
sync.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
    const syncForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
        syncForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
export const complete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
complete.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return complete.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
complete.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
    const completeForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
        completeForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
const clerking = {
    summary: Object.assign(summary, summary7469d3),
pause: Object.assign(pause, pause),
resume: Object.assign(resume, resume),
sync: Object.assign(sync, sync),
complete: Object.assign(complete, complete),
}

export default clerking