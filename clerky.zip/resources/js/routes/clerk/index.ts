import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(options),
    method: 'get',
})

start.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerk/start',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: start.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: start.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
        startForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: start.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
        startForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: start.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
export const redirect = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(args, options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerk/{unit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.url = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { unit: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.slug
                : args.unit,
                }

    return redirect.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.get = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.head = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
    const redirectForm = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirect.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
        redirectForm.get = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
        redirectForm.head = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirect.form = redirectForm