import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../wayfinder'
/**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
export const pulse = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pulse.url(options),
    method: 'get',
})

pulse.definition = {
    methods: ["get","head"],
    url: '/pulse',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
pulse.url = (options?: RouteQueryOptions) => {
    return pulse.definition.url + queryParams(options)
}

/**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
pulse.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pulse.url(options),
    method: 'get',
})
/**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
pulse.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pulse.url(options),
    method: 'head',
})

    /**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
    const pulseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pulse.url(options),
        method: 'get',
    })

            /**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
        pulseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pulse.url(options),
            method: 'get',
        })
            /**
 * @see vendor/laravel/pulse/src/PulseServiceProvider.php:116
 * @route '/pulse'
 */
        pulseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pulse.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pulse.form = pulseForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
        registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/register'
 */
        registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DashboardController::dashboard
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
export const clerk = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerk.url(args, options),
    method: 'get',
})

clerk.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return clerk.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerk.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clerk.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
    const clerkForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clerk.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
        clerkForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerk.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
        clerkForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerk.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clerk.form = clerkForm
/**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
export const contribute = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contribute.url(options),
    method: 'get',
})

contribute.definition = {
    methods: ["get","head"],
    url: '/dashboard/contribute',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
contribute.url = (options?: RouteQueryOptions) => {
    return contribute.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
contribute.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contribute.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
contribute.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contribute.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
    const contributeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contribute.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
        contributeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contribute.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ContributeController::contribute
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
        contributeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contribute.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contribute.form = contributeForm
/**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
export const settings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
settings.url = (options?: RouteQueryOptions) => {
    return settings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
settings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
settings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
    const settingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
        settingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SettingsController::settings
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
        settingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
/**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
export const donate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: donate.url(options),
    method: 'get',
})

donate.definition = {
    methods: ["get","head"],
    url: '/dashboard/donate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
donate.url = (options?: RouteQueryOptions) => {
    return donate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
donate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: donate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
donate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: donate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
    const donateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: donate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
        donateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: donate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DonationController::donate
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
        donateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: donate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    donate.form = donateForm