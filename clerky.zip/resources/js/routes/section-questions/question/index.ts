import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::store
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
export const store = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/section-questions/{template}/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::store
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
store.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return store.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::store
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
store.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::store
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
    const storeForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::store
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
        storeForm.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorder
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(options),
    method: 'patch',
})

reorder.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorder
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorder
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
reorder.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorder
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorder
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
        reorderForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::update
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
export const update = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/{question}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::update
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
update.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return update.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::update
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
update.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::update
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
    const updateForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::update
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
        updateForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroy
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
export const destroy = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/section-questions/{template}/question/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroy
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
destroy.url = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    question: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroy.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroy
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
destroy.delete = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroy
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
    const destroyForm = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroy
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
        destroyForm.delete = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
export const updateDependency = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

updateDependency.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/{question}/dependency',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
updateDependency.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateDependency.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
updateDependency.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
    const updateDependencyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDependency.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
        updateDependencyForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDependency.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDependency.form = updateDependencyForm
const question = {
    store: Object.assign(store, store),
reorder: Object.assign(reorder, reorder),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
updateDependency: Object.assign(updateDependency, updateDependency),
}

export default question