import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import question from './question'
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/section-questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
export const show = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/section-questions/{template}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.url = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { template: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.slug
                : args.template,
                }

    return show.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
    const showForm = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
        showForm.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
        showForm.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const sectionQuestions = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
question: Object.assign(question, question),
}

export default sectionQuestions