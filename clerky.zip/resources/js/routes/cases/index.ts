import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
export const all = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})

all.definition = {
    methods: ["get","head"],
    url: '/dashboard/cases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
all.url = (options?: RouteQueryOptions) => {
    return all.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
all.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: all.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
all.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: all.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
    const allForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: all.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
        allForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\CaseController::all
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
        allForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: all.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    all.form = allForm
/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
export const destroy = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/cases/{clerking}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
destroy.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return destroy.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
destroy.delete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
    const destroyForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
        destroyForm.delete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const cases = {
    all: Object.assign(all, all),
destroy: Object.assign(destroy, destroy),
}

export default cases