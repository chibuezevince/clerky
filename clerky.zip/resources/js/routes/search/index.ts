import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
export const clerkings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerkings.url(options),
    method: 'get',
})

clerkings.definition = {
    methods: ["get","head"],
    url: '/dashboard/search/clerkings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
clerkings.url = (options?: RouteQueryOptions) => {
    return clerkings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
clerkings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerkings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
clerkings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clerkings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
    const clerkingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clerkings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
        clerkingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerkings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\CaseController::clerkings
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
        clerkingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerkings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clerkings.form = clerkingsForm
const search = {
    clerkings: Object.assign(clerkings, clerkings),
}

export default search