import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::submit
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:30
 * @route '/email/verify'
 */
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/email/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::submit
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:30
 * @route '/email/verify'
 */
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::submit
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:30
 * @route '/email/verify'
 */
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\EmailVerificationController::submit
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:30
 * @route '/email/verify'
 */
    const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\EmailVerificationController::submit
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:30
 * @route '/email/verify'
 */
        submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(options),
            method: 'post',
        })
    
    submit.form = submitForm
const verify = {
    submit: Object.assign(submit, submit),
}

export default verify