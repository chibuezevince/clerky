import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import verify from './verify'
/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::resend
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:46
 * @route '/email/resend'
 */
export const resend = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resend.url(options),
    method: 'post',
})

resend.definition = {
    methods: ["post"],
    url: '/email/resend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::resend
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:46
 * @route '/email/resend'
 */
resend.url = (options?: RouteQueryOptions) => {
    return resend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\EmailVerificationController::resend
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:46
 * @route '/email/resend'
 */
resend.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resend.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\EmailVerificationController::resend
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:46
 * @route '/email/resend'
 */
    const resendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resend.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\EmailVerificationController::resend
 * @see app/Http/Controllers/Auth/EmailVerificationController.php:46
 * @route '/email/resend'
 */
        resendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resend.url(options),
            method: 'post',
        })
    
    resend.form = resendForm
const email = {
    resend: Object.assign(resend, resend),
verify: Object.assign(verify, verify),
}

export default email