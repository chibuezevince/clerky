import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\PasswordRecoveryController::submit
 * @see app/Http/Controllers/Auth/PasswordRecoveryController.php:36
 * @route '/reset-password'
 */
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Auth\PasswordRecoveryController::submit
 * @see app/Http/Controllers/Auth/PasswordRecoveryController.php:36
 * @route '/reset-password'
 */
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\PasswordRecoveryController::submit
 * @see app/Http/Controllers/Auth/PasswordRecoveryController.php:36
 * @route '/reset-password'
 */
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Auth\PasswordRecoveryController::submit
 * @see app/Http/Controllers/Auth/PasswordRecoveryController.php:36
 * @route '/reset-password'
 */
    const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Auth\PasswordRecoveryController::submit
 * @see app/Http/Controllers/Auth/PasswordRecoveryController.php:36
 * @route '/reset-password'
 */
        submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(options),
            method: 'post',
        })
    
    submit.form = submitForm
const reset = {
    submit: Object.assign(submit, submit),
}

export default reset