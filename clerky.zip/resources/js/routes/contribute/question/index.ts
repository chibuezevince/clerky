import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\ContributeController::reorder
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
export const reorder = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(options),
    method: 'patch',
})

reorder.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/question/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::reorder
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
reorder.url = (options?: RouteQueryOptions) => {
    return reorder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::reorder
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
reorder.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::reorder
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
    const reorderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::reorder
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
        reorderForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Home\ContributeController::store
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/contribute/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::store
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::store
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::store
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::store
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Home\ContributeController::destroy
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
export const destroy = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/contribute/question/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::destroy
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
destroy.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroy.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::destroy
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
destroy.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::destroy
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
    const destroyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::destroy
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
        destroyForm.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Home\ContributeController::update
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
export const update = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/question/{question}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::update
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
update.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return update.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::update
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
update.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::update
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
    const updateForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::update
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
        updateForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
export const updateDependency = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

updateDependency.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/questions/{question}/dependency',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
updateDependency.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateDependency.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
updateDependency.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
    const updateDependencyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDependency.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
        updateDependencyForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDependency.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDependency.form = updateDependencyForm
const question = {
    reorder: Object.assign(reorder, reorder),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
update: Object.assign(update, update),
updateDependency: Object.assign(updateDependency, updateDependency),
}

export default question