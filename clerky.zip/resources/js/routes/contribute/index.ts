import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import question from './question'
/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
export const show = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/contribute/{template}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.url = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { template: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.slug
                : args.template,
                }

    return show.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
    const showForm = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
        showForm.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
        showForm.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const contribute = {
    show: Object.assign(show, show),
question: Object.assign(question, question),
}

export default contribute