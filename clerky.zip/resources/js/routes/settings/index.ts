import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Home\SettingsController::avatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
export const avatar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: avatar.url(options),
    method: 'post',
})

avatar.definition = {
    methods: ["post"],
    url: '/dashboard/settings/avatar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::avatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
avatar.url = (options?: RouteQueryOptions) => {
    return avatar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::avatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
avatar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: avatar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::avatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
    const avatarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: avatar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::avatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
        avatarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: avatar.url(options),
            method: 'post',
        })
    
    avatar.form = avatarForm
/**
* @see \App\Http\Controllers\Home\SettingsController::password
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
export const password = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: password.url(options),
    method: 'patch',
})

password.definition = {
    methods: ["patch"],
    url: '/dashboard/settings/password',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::password
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
password.url = (options?: RouteQueryOptions) => {
    return password.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::password
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
password.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: password.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::password
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
    const passwordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: password.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::password
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
        passwordForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: password.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    password.form = passwordForm
const settings = {
    update: Object.assign(update, update),
avatar: Object.assign(avatar, avatar),
password: Object.assign(password, password),
}

export default settings