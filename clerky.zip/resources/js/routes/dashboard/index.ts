import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
export const setup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: setup.url(options),
    method: 'get',
})

setup.definition = {
    methods: ["get","head"],
    url: '/dashboard/setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.url = (options?: RouteQueryOptions) => {
    return setup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: setup.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: setup.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
    const setupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: setup.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
        setupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: setup.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
        setupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: setup.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    setup.form = setupForm