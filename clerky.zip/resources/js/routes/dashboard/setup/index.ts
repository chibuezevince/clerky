import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\DashboardController::submit
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/dashboard/setup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::submit
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::submit
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::submit
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
    const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::submit
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
        submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(options),
            method: 'post',
        })
    
    submit.form = submitForm