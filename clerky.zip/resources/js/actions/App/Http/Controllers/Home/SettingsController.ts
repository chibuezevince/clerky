import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SettingsController::index
 * @see app/Http/Controllers/Home/SettingsController.php:13
 * @route '/dashboard/settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/dashboard/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::update
 * @see app/Http/Controllers/Home/SettingsController.php:39
 * @route '/dashboard/settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Home\SettingsController::uploadAvatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
export const uploadAvatar = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAvatar.url(options),
    method: 'post',
})

uploadAvatar.definition = {
    methods: ["post"],
    url: '/dashboard/settings/avatar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::uploadAvatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
uploadAvatar.url = (options?: RouteQueryOptions) => {
    return uploadAvatar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::uploadAvatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
uploadAvatar.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAvatar.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::uploadAvatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
    const uploadAvatarForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadAvatar.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::uploadAvatar
 * @see app/Http/Controllers/Home/SettingsController.php:67
 * @route '/dashboard/settings/avatar'
 */
        uploadAvatarForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadAvatar.url(options),
            method: 'post',
        })
    
    uploadAvatar.form = uploadAvatarForm
/**
* @see \App\Http\Controllers\Home\SettingsController::changePassword
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
export const changePassword = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: changePassword.url(options),
    method: 'patch',
})

changePassword.definition = {
    methods: ["patch"],
    url: '/dashboard/settings/password',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SettingsController::changePassword
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
changePassword.url = (options?: RouteQueryOptions) => {
    return changePassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SettingsController::changePassword
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
changePassword.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: changePassword.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SettingsController::changePassword
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
    const changePasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: changePassword.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SettingsController::changePassword
 * @see app/Http/Controllers/Home/SettingsController.php:89
 * @route '/dashboard/settings/password'
 */
        changePasswordForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: changePassword.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    changePassword.form = changePasswordForm
const SettingsController = { index, update, uploadAvatar, changePassword }

export default SettingsController