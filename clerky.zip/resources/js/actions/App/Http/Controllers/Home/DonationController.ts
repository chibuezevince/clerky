import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/donate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DonationController::index
 * @see app/Http/Controllers/Home/DonationController.php:11
 * @route '/dashboard/donate'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DonationController = { index }

export default DonationController