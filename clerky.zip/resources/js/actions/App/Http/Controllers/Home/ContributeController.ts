import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/contribute',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ContributeController::index
 * @see app/Http/Controllers/Home/ContributeController.php:14
 * @route '/dashboard/contribute'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
export const show = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/contribute/{template}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.url = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { template: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.slug
                : args.template,
                }

    return show.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
show.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
    const showForm = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
        showForm.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ContributeController::show
 * @see app/Http/Controllers/Home/ContributeController.php:28
 * @route '/dashboard/contribute/{template}'
 */
        showForm.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Home\ContributeController::reorderQuestions
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
export const reorderQuestions = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorderQuestions.url(options),
    method: 'patch',
})

reorderQuestions.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/question/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::reorderQuestions
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
reorderQuestions.url = (options?: RouteQueryOptions) => {
    return reorderQuestions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::reorderQuestions
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
reorderQuestions.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorderQuestions.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::reorderQuestions
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
    const reorderQuestionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderQuestions.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::reorderQuestions
 * @see app/Http/Controllers/Home/ContributeController.php:138
 * @route '/dashboard/contribute/question/reorder'
 */
        reorderQuestionsForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderQuestions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reorderQuestions.form = reorderQuestionsForm
/**
* @see \App\Http\Controllers\Home\ContributeController::storeQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
export const storeQuestion = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(options),
    method: 'post',
})

storeQuestion.definition = {
    methods: ["post"],
    url: '/dashboard/contribute/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::storeQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
storeQuestion.url = (options?: RouteQueryOptions) => {
    return storeQuestion.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::storeQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
storeQuestion.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::storeQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
    const storeQuestionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeQuestion.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::storeQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:178
 * @route '/dashboard/contribute/question'
 */
        storeQuestionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeQuestion.url(options),
            method: 'post',
        })
    
    storeQuestion.form = storeQuestionForm
/**
* @see \App\Http\Controllers\Home\ContributeController::destroyQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
export const destroyQuestion = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

destroyQuestion.definition = {
    methods: ["delete"],
    url: '/dashboard/contribute/question/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::destroyQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
destroyQuestion.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroyQuestion.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::destroyQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
destroyQuestion.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::destroyQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
    const destroyQuestionForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::destroyQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:229
 * @route '/dashboard/contribute/question/{question}'
 */
        destroyQuestionForm.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyQuestion.form = destroyQuestionForm
/**
* @see \App\Http\Controllers\Home\ContributeController::updateQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
export const updateQuestion = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateQuestion.url(args, options),
    method: 'patch',
})

updateQuestion.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/question/{question}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::updateQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
updateQuestion.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateQuestion.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::updateQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
updateQuestion.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateQuestion.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::updateQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
    const updateQuestionForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::updateQuestion
 * @see app/Http/Controllers/Home/ContributeController.php:42
 * @route '/dashboard/contribute/question/{question}'
 */
        updateQuestionForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateQuestion.form = updateQuestionForm
/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
export const updateDependency = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

updateDependency.definition = {
    methods: ["patch"],
    url: '/dashboard/contribute/questions/{question}/dependency',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
updateDependency.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateDependency.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
updateDependency.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
    const updateDependencyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDependency.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ContributeController::updateDependency
 * @see app/Http/Controllers/Home/ContributeController.php:151
 * @route '/dashboard/contribute/questions/{question}/dependency'
 */
        updateDependencyForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDependency.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDependency.form = updateDependencyForm
const ContributeController = { index, show, reorderQuestions, storeQuestion, destroyQuestion, updateQuestion, updateDependency }

export default ContributeController