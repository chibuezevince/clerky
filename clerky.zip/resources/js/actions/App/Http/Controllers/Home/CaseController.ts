import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/cases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\CaseController::index
 * @see app/Http/Controllers/Home/CaseController.php:12
 * @route '/dashboard/cases'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
export const destroy = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/cases/{clerking}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
destroy.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return destroy.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
destroy.delete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
    const destroyForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::destroy
 * @see app/Http/Controllers/Home/CaseController.php:42
 * @route '/dashboard/cases/{clerking}'
 */
        destroyForm.delete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/dashboard/search/clerkings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: search.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
        searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\CaseController::search
 * @see app/Http/Controllers/Home/CaseController.php:48
 * @route '/dashboard/search/clerkings'
 */
        searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    search.form = searchForm
const CaseController = { index, destroy, search }

export default CaseController