import DashboardController from './DashboardController'
import ClerkingController from './ClerkingController'
import CaseController from './CaseController'
import ContributeController from './ContributeController'
import SectionQuestionController from './SectionQuestionController'
import SettingsController from './SettingsController'
import DonationController from './DonationController'
import NotificationsController from './NotificationsController'
const Home = {
    DashboardController: Object.assign(DashboardController, DashboardController),
ClerkingController: Object.assign(ClerkingController, ClerkingController),
CaseController: Object.assign(CaseController, CaseController),
ContributeController: Object.assign(ContributeController, ContributeController),
SectionQuestionController: Object.assign(SectionQuestionController, SectionQuestionController),
SettingsController: Object.assign(SettingsController, SettingsController),
DonationController: Object.assign(DonationController, DonationController),
NotificationsController: Object.assign(NotificationsController, NotificationsController),
}

export default Home