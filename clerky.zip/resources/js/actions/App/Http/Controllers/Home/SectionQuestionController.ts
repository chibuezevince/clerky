import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/section-questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::index
 * @see app/Http/Controllers/Home/SectionQuestionController.php:14
 * @route '/dashboard/section-questions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
export const show = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/section-questions/{template}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.url = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { template: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.slug
                : args.template,
                }

    return show.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
show.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
    const showForm = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
        showForm.get = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::show
 * @see app/Http/Controllers/Home/SectionQuestionController.php:30
 * @route '/dashboard/section-questions/{template}'
 */
        showForm.head = (args: { template: string | { slug: string } } | [template: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::storeQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
export const storeQuestion = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

storeQuestion.definition = {
    methods: ["post"],
    url: '/dashboard/section-questions/{template}/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::storeQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
storeQuestion.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return storeQuestion.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::storeQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
storeQuestion.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::storeQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
    const storeQuestionForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeQuestion.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::storeQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:51
 * @route '/dashboard/section-questions/{template}/question'
 */
        storeQuestionForm.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeQuestion.url(args, options),
            method: 'post',
        })
    
    storeQuestion.form = storeQuestionForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorderQuestions
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
export const reorderQuestions = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorderQuestions.url(options),
    method: 'patch',
})

reorderQuestions.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorderQuestions
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
reorderQuestions.url = (options?: RouteQueryOptions) => {
    return reorderQuestions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorderQuestions
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
reorderQuestions.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorderQuestions.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorderQuestions
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
    const reorderQuestionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorderQuestions.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::reorderQuestions
 * @see app/Http/Controllers/Home/SectionQuestionController.php:208
 * @route '/dashboard/section-questions/question/reorder'
 */
        reorderQuestionsForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorderQuestions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reorderQuestions.form = reorderQuestionsForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
export const updateQuestion = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateQuestion.url(args, options),
    method: 'patch',
})

updateQuestion.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/{question}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
updateQuestion.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateQuestion.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
updateQuestion.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateQuestion.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
    const updateQuestionForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:99
 * @route '/dashboard/section-questions/question/{question}'
 */
        updateQuestionForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateQuestion.form = updateQuestionForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroyQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
export const destroyQuestion = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

destroyQuestion.definition = {
    methods: ["delete"],
    url: '/dashboard/section-questions/{template}/question/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroyQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
destroyQuestion.url = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    question: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroyQuestion.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroyQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
destroyQuestion.delete = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroyQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
    const destroyQuestionForm = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::destroyQuestion
 * @see app/Http/Controllers/Home/SectionQuestionController.php:202
 * @route '/dashboard/section-questions/{template}/question/{question}'
 */
        destroyQuestionForm.delete = (args: { template: number | { id: number }, question: number | { id: number } } | [template: number | { id: number }, question: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyQuestion.form = destroyQuestionForm
/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
export const updateDependency = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

updateDependency.definition = {
    methods: ["patch"],
    url: '/dashboard/section-questions/question/{question}/dependency',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
updateDependency.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateDependency.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
updateDependency.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDependency.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
    const updateDependencyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDependency.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\SectionQuestionController::updateDependency
 * @see app/Http/Controllers/Home/SectionQuestionController.php:227
 * @route '/dashboard/section-questions/question/{question}/dependency'
 */
        updateDependencyForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDependency.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDependency.form = updateDependencyForm
const SectionQuestionController = { index, show, storeQuestion, reorderQuestions, updateQuestion, destroyQuestion, updateDependency }

export default SectionQuestionController