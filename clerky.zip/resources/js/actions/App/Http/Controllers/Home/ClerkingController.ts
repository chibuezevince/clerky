import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(options),
    method: 'get',
})

start.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerk/start',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
start.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: start.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: start.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
        startForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: start.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::start
 * @see app/Http/Controllers/Home/ClerkingController.php:21
 * @route '/dashboard/clerk/start'
 */
        startForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: start.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
export const redirect = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(args, options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerk/{unit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.url = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { unit: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.slug
                : args.unit,
                }

    return redirect.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.get = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
redirect.head = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
    const redirectForm = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirect.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
        redirectForm.get = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::redirect
 * @see app/Http/Controllers/Home/ClerkingController.php:27
 * @route '/dashboard/clerk/{unit}'
 */
        redirectForm.head = (args: { unit: string | { slug: string } } | [unit: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirect.form = redirectForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
export const clerk = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerk.url(args, options),
    method: 'get',
})

clerk.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return clerk.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clerk.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
clerk.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clerk.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
    const clerkForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clerk.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
        clerkForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerk.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::clerk
 * @see app/Http/Controllers/Home/ClerkingController.php:48
 * @route '/dashboard/clerking/{clerking}'
 */
        clerkForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clerk.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clerk.form = clerkForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
export const summary = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(args, options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return summary.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
summary.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
    const summaryForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summary.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        summaryForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::summary
 * @see app/Http/Controllers/Home/ClerkingController.php:235
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        summaryForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summary.form = summaryForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::generateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
export const generateSummary = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateSummary.url(args, options),
    method: 'post',
})

generateSummary.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/summary/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::generateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
generateSummary.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return generateSummary.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::generateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
generateSummary.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateSummary.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::generateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
    const generateSummaryForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateSummary.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::generateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:255
 * @route '/dashboard/clerking/{clerking}/summary/generate'
 */
        generateSummaryForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateSummary.url(args, options),
            method: 'post',
        })
    
    generateSummary.form = generateSummaryForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
export const summaryEdit = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summaryEdit.url(args, options),
    method: 'get',
})

summaryEdit.definition = {
    methods: ["get","head"],
    url: '/dashboard/clerking/{clerking}/summary/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
summaryEdit.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return summaryEdit.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
summaryEdit.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summaryEdit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
summaryEdit.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summaryEdit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
    const summaryEditForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summaryEdit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
        summaryEditForm.get = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summaryEdit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\ClerkingController::summaryEdit
 * @see app/Http/Controllers/Home/ClerkingController.php:269
 * @route '/dashboard/clerking/{clerking}/summary/edit'
 */
        summaryEditForm.head = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summaryEdit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summaryEdit.form = summaryEditForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::updateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
export const updateSummary = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSummary.url(args, options),
    method: 'patch',
})

updateSummary.definition = {
    methods: ["patch"],
    url: '/dashboard/clerking/{clerking}/summary',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::updateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
updateSummary.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return updateSummary.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::updateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
updateSummary.patch = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSummary.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::updateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
    const updateSummaryForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSummary.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::updateSummary
 * @see app/Http/Controllers/Home/ClerkingController.php:277
 * @route '/dashboard/clerking/{clerking}/summary'
 */
        updateSummaryForm.patch = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSummary.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSummary.form = updateSummaryForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
export const pause = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

pause.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
pause.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return pause.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
pause.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
    const pauseForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pause.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::pause
 * @see app/Http/Controllers/Home/ClerkingController.php:73
 * @route '/dashboard/clerking/{clerking}/pause'
 */
        pauseForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pause.url(args, options),
            method: 'post',
        })
    
    pause.form = pauseForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
export const resume = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
resume.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return resume.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
resume.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
    const resumeForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resume.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::resume
 * @see app/Http/Controllers/Home/ClerkingController.php:86
 * @route '/dashboard/clerking/{clerking}/resume'
 */
        resumeForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resume.url(args, options),
            method: 'post',
        })
    
    resume.form = resumeForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
export const sync = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
sync.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return sync.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
sync.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
    const syncForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::sync
 * @see app/Http/Controllers/Home/ClerkingController.php:98
 * @route '/dashboard/clerking/{clerking}/sync'
 */
        syncForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
export const complete = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/dashboard/clerking/{clerking}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
complete.url = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clerking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'session_id' in args) {
            args = { clerking: args.session_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    clerking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        clerking: typeof args.clerking === 'object'
                ? args.clerking.session_id
                : args.clerking,
                }

    return complete.definition.url
            .replace('{clerking}', parsedArgs.clerking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
complete.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
    const completeForm = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\ClerkingController::complete
 * @see app/Http/Controllers/Home/ClerkingController.php:222
 * @route '/dashboard/clerking/{clerking}/complete'
 */
        completeForm.post = (args: { clerking: string | { session_id: string } } | [clerking: string | { session_id: string } ] | string | { session_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
const ClerkingController = { start, redirect, clerk, summary, generateSummary, summaryEdit, updateSummary, pause, resume, sync, complete }

export default ClerkingController