import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
export const setup = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: setup.url(options),
    method: 'get',
})

setup.definition = {
    methods: ["get","head"],
    url: '/dashboard/setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.url = (options?: RouteQueryOptions) => {
    return setup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: setup.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
setup.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: setup.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
    const setupForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: setup.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
        setupForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: setup.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DashboardController::setup
 * @see app/Http/Controllers/Home/DashboardController.php:17
 * @route '/dashboard/setup'
 */
        setupForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: setup.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    setup.form = setupForm
/**
* @see \App\Http\Controllers\Home\DashboardController::completeSetup
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
export const completeSetup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeSetup.url(options),
    method: 'post',
})

completeSetup.definition = {
    methods: ["post"],
    url: '/dashboard/setup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::completeSetup
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
completeSetup.url = (options?: RouteQueryOptions) => {
    return completeSetup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::completeSetup
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
completeSetup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeSetup.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::completeSetup
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
    const completeSetupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: completeSetup.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::completeSetup
 * @see app/Http/Controllers/Home/DashboardController.php:28
 * @route '/dashboard/setup'
 */
        completeSetupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: completeSetup.url(options),
            method: 'post',
        })
    
    completeSetup.form = completeSetupForm
/**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Home\DashboardController::index
 * @see app/Http/Controllers/Home/DashboardController.php:50
 * @route '/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DashboardController = { setup, completeSetup, index }

export default DashboardController