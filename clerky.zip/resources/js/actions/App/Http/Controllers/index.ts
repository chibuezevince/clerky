import Auth from './Auth'
import Home from './Home'
import Admin from './Admin'
const Controllers = {
    Auth: Object.assign(Auth, Auth),
Home: Object.assign(Home, Home),
Admin: Object.assign(Admin, Admin),
}

export default Controllers