import RegisterController from './RegisterController'
import Oauth2Controller from './Oauth2Controller'
import LoginController from './LoginController'
import PasswordRecoveryController from './PasswordRecoveryController'
import EmailVerificationController from './EmailVerificationController'
const Auth = {
    RegisterController: Object.assign(RegisterController, RegisterController),
Oauth2Controller: Object.assign(Oauth2Controller, Oauth2Controller),
LoginController: Object.assign(LoginController, LoginController),
PasswordRecoveryController: Object.assign(PasswordRecoveryController, PasswordRecoveryController),
EmailVerificationController: Object.assign(EmailVerificationController, EmailVerificationController),
}

export default Auth